# THE ANSWER DESK
Customer service desk for Mediahuis subscriber correspondence

## WHAT IS THIS?
A tool that drafts customer service emails for Mediahuis
Nederland subscriber cases. You pick the publication and the case
type, paste in the customer's incoming email, optionally give a
short direction, and the tool uses Claude to produce a complete,
ready-to-send Dutch email draft.

Note: the tool always writes the draft in Dutch, since that is
the language used for subscriber correspondence.

## SCREENSHOTS
*(Illustrative mockups of the layout, not live captures — they
follow the tool's actual design.)*

**Starting screen:**

![Starting screen of De Antwoordredactie](screenshot-leeg.png)

**After drafting a reply:**

![Draft generated, with copy button and stamp](screenshot-concept.png)

## HOW TO USE IT
1. Choose the publication (De Telegraaf, Noordhollands Dagblad,
   Gooi- en Eemlander, Leidsch Dagblad, Privé, Vrouw, or
   Autovisie) under "Titel".
2. Choose the case type under "Rubriek":
   - Price increase / prevent cancellation
   - Confirm cancellation / correct end date
   - Delivery complaint / compensation
   - Collections / payment dispute
   - Digital access (login / app)
   - Invoice / payment question
   - Address change / account details
   - Bereavement / legal guardian (bewindvoerder)
3. Paste the customer's email into the "Inkomend" (Incoming) box.
4. Optionally add a short instruction in "Richting voor antwoord"
   (Direction for reply), e.g. "confirm cancellation effective
   October 1, no goodwill offer". This field can be left blank.
5. Click "Stel concept op" (Draft the reply). The draft appears
   on the right.
6. Edit the text in the draft box if needed — it's a normal
   editable text field.
7. Click "Kopieer" (Copy) to copy the text to your clipboard and
   paste it into your email system.

## TONE PER CASE TYPE
The tool automatically adjusts tone based on the selected case
type: warm and solution-oriented for price-increase/retention
cases, businesslike and neutral for collections disputes, and
very careful, empathetic, and unhurried for bereavement/legal
guardian cases.

## BUILT-IN CONTACT DETAILS
- Retention team (price increase / prevent cancellation):
  088 - 824 8242, weekdays 08:00-17:00
- Noordhollands Dagblad customer service (for digital access
  issues specific to this title):
  088 - 824 11 11, weekdays 08:00-17:00

These numbers are only mentioned when relevant to the selected
case type and publication.

## IMPORTANT
- Every draft is a starting point, not a final answer: always
  review it before sending.
- No placeholders like [name] are used; if the customer's name
  isn't clear from the email, the draft uses "Geachte klant,"
  (Dear customer,) as the salutation.
- The file mediahuis-desk.jsx is a React component and runs as
  an interactive artifact in Claude.

## FILES
- mediahuis-desk.jsx     - the tool itself
- readme.md              - Dutch version of this document
- readme-en.md           - this document
- screenshot-leeg.png    - starting screen
- screenshot-concept.png - screen with a generated draft
